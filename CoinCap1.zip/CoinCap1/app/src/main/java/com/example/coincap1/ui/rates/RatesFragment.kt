package com.example.coincap1.ui.rates

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.coincap1.data.rates.DataModel
import com.example.coincap1.data.rates.RatesModel
import com.example.coincap1.databinding.FragmentRatesBinding

class RatesFragment : Fragment() {

    private lateinit var viewModel: RatesViewModel
    private var _binding: FragmentRatesBinding? = null
    private val binding get() = _binding!!


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        viewModel =
            ViewModelProvider(this)[RatesViewModel::class.java]
        _binding = FragmentRatesBinding.inflate(inflater, container, false)

        viewModel.rates.observe(viewLifecycleOwner) {
            it?.let {
                setupUI(it)
            }
        }

        viewModel.getRates()

        return binding.root
    }

    private fun setupUI(rates: RatesModel) {
        binding.rvRates.apply {
            layoutManager = LinearLayoutManager(context)
            adapter = RatesAdapter(rates.data as List<DataModel>?)
        }

    }

}