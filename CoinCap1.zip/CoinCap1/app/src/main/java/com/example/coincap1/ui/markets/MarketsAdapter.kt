package com.example.coincap1.ui.markets

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.example.coincap1.R
import com.example.coincap1.data.markets.DataModel
import com.example.coincap1.data.markets.MarketsModel
import com.example.coincap1.databinding.ItemMarketsBinding

class MarketsAdapter(val markets: List<DataModel>?) :
    RecyclerView.Adapter<MarketsAdapter.ViewHolder>() {

    // ITEM/ROW all the settings/UI of individual items
    class ViewHolder(val view: View) : RecyclerView.ViewHolder(view) {
        private val binding = ItemMarketsBinding.bind(view)

        fun handleData(item: DataModel?) {
            binding.textView2.text = item?.baseId
            binding.textView3.text = item?.baseSymbol
            binding.textView4.text =item?.rank


            if (adapterPosition % 2 == 0) {
                binding.llMarkets.setBackgroundColor(
                    ContextCompat.getColor(
                        view.context,
                        R.color.purple_200
                    )
                )
            } else {
                binding.llMarkets.setBackgroundColor(
                    ContextCompat.getColor(
                        view.context,
                        R.color.purple_700
                    )
                )
            }
        }

    }

    // Creates the ITEM/ROW for the UI
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MarketsAdapter.ViewHolder {

        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_markets, parent, false)

        return ViewHolder(view)
    }

    // Size of the list
    override fun getItemCount(): Int = markets?.size ?: 0

    // Handle the CURRENT item you are on
    override fun onBindViewHolder(holder: MarketsAdapter.ViewHolder, position: Int) {
        holder.handleData(markets?.get(position))
    }

}
